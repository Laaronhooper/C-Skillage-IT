﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SkillageITStockApp
{
   public class Toy
    {

        public int ItemCode { get; set; }
        public string ItemDescription { get; set; }
        public int CurrentCount { get; set; }
        public bool OnOrder { get; set; }

        public Toy()
        {
        }

        public Toy(int ItemCode, string ItemDescription, int CurrentCount, bool OnOrder)
        {
            this.ItemCode = ItemCode;
            this.ItemDescription = ItemDescription;
            this.CurrentCount = CurrentCount;
            this.OnOrder = OnOrder;

        }
    }
}
