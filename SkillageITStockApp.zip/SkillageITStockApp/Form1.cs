﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace SkillageITStockApp
{
    public partial class Form1 : Form
    {
        DataGridView mydatagridview = new DataGridView();
        DataTable mydatatable = new DataTable();

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void Button_Click(object sender, EventArgs e)
        {
            {
                //this.Size = new Size(750, 500);
                //mydatagridview.Size = new Size(600, 400);
                //mydatagridview.Location = new Point(5, 5);


                var path = @"C:\Users\Luke\Desktop\stocklist.txt";


                //List<Tuple<int, string, int, bool>> toys = new List<Tuple<int,string,int,bool>>();
             
                List<Toy> toys = new List<Toy>();
                List<string> lines = File.ReadAllLines(path).Skip(1).ToList();
                        
                foreach (var line in lines)
                {
                    string[] entries = line.Split(',');

                    Toy newToy = new Toy();
                   
                    //ItemCode = Int32.TryParse(TextBoxD1.Text, out entries[0]);
                    newToy.ItemCode = Convert.ToInt32(entries[0]);
                    newToy.ItemDescription = entries[1];
                    newToy.CurrentCount = Convert.ToInt32(entries[2]);
                    newToy.OnOrder = Convert.ToBoolean(entries[3]);

                    toys.Add(newToy);
                }

                foreach (var toy in toys)
                {
                    Console.WriteLine($"{toy.ItemCode},{toy.ItemDescription},{toy.CurrentCount},{toy.OnOrder}");
                }

                Console.ReadLine();

            }
        }
    }
}